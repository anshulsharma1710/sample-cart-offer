package com.springboot.repository;

public interface StudentRepository {
	
}