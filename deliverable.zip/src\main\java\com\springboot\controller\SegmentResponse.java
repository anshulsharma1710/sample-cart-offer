package com.springboot.controller;

import lombok.Data;

@Data
public class SegmentResponse {
    private String segment;
}
